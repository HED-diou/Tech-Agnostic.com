---
name: charte-graphique
description: >-
  The Deltavantis brand system — logo, colour, typography, layout, components,
  motion, iconography and voice. Use this skill whenever you create or modify
  ANYTHING that carries the Deltavantis name: a web page or component, a
  slide, a PDF or proposal, a social image, an email signature, a favicon, a
  diagram, a chart, an ad, or any copy written in the company's voice. Load it
  BEFORE writing the first line of markup, choosing a colour, or picking a font.
  Triggers on "Deltavantis", "deltavantis.com", "our brand", "brand
  guidelines", "charte graphique", "the logo", "brand colours", "house style".
---

# Deltavantis — Charte Graphique

The full charter is maintained as a single source of truth at the repository
root. **Read it now, before doing anything else:**

→ **`skill-charte-graphic.md`**

Supporting documents:

- `docs/BRAND.md` — the formal specification. Wins over everything if they disagree.
- `docs/BRD.md` — business context: what the company is and what the site is for.

Do not answer brand questions from memory or from this stub. Open
`skill-charte-graphic.md` and follow it, including the QA gate in §10.
